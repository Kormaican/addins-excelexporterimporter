﻿//#error Change this information then comment this line
//#error Change the Addin.tt template then comment this line


namespace ExcelExporterImporter
{
    public static class AddinInfo
    {
        public const string AddinName = "Export/ImportExcel";
        public const string ButtonName = "Export/ImportExcel";
        public const string ButtonText = "Export/Import\nExcel";
        public const string AddinDescription = "Transfer data back and forth between Revit and Excel";
    }
}