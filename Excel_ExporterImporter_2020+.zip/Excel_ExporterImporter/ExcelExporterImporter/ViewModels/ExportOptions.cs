namespace ExcelExporterImporter.ViewModels
{
    public enum ExportOptions
    {
        SeparateTables,
        SeparateFiles
    }

    public enum ExportOptionsBasic
    {
        SeparateTables,
        SeparateFiles
    }
}